---
name: Obsidian Slate & Electric Cyan
colors:
  surface: '#0b1326'
  surface-dim: '#0b1326'
  surface-bright: '#31394d'
  surface-container-lowest: '#060e20'
  surface-container-low: '#131b2e'
  surface-container: '#171f33'
  surface-container-high: '#222a3d'
  surface-container-highest: '#2d3449'
  on-surface: '#dae2fd'
  on-surface-variant: '#b9cacb'
  inverse-surface: '#dae2fd'
  inverse-on-surface: '#283044'
  outline: '#849495'
  outline-variant: '#3a494b'
  surface-tint: '#00dce6'
  primary: '#e0fdff'
  on-primary: '#00373a'
  primary-container: '#00f2fe'
  on-primary-container: '#006a70'
  inverse-primary: '#00696f'
  secondary: '#70ffb9'
  on-secondary: '#003822'
  secondary-container: '#01e598'
  on-secondary-container: '#00613e'
  tertiary: '#f1f8ff'
  on-tertiary: '#00354a'
  tertiary-container: '#b2e1ff'
  on-tertiary-container: '#00678c'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#6ff6ff'
  primary-fixed-dim: '#00dce6'
  on-primary-fixed: '#002022'
  on-primary-fixed-variant: '#004f53'
  secondary-fixed: '#4effb1'
  secondary-fixed-dim: '#00e295'
  on-secondary-fixed: '#002112'
  on-secondary-fixed-variant: '#005233'
  tertiary-fixed: '#c4e7ff'
  tertiary-fixed-dim: '#7bd0ff'
  on-tertiary-fixed: '#001e2c'
  on-tertiary-fixed-variant: '#004c69'
  background: '#0b1326'
  on-background: '#dae2fd'
  surface-variant: '#2d3449'
typography:
  display-xl:
    fontFamily: Inter
    fontSize: 56px
    fontWeight: '800'
    lineHeight: 64px
    letterSpacing: -0.03em
  display-xl-mobile:
    fontFamily: Inter
    fontSize: 38px
    fontWeight: '800'
    lineHeight: 44px
    letterSpacing: -0.025em
  headline-lg:
    fontFamily: Inter
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 34px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
  code-inline:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
  code-block:
    fontFamily: JetBrains Mono
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
  label-md:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.06em
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.08em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 3rem
  margin-mobile: 1.25rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system expresses the caliber of a senior-tier software engineer who crafts mission-critical, scalable systems with architectural rigor and polish. The aesthetic balances deep obsidian and dark slate surfaces with controlled bursts of electric cyan and radiant emerald, conveying technical mastery, executive confidence, and analytical depth.

The interface targets technical recruiters, VP/Directors of Engineering, and technical co-founders. It delivers immediate impact without superfluous ornament: readability is paramount, metrics are foregrounded, and code artifacts feel native to an ultra-modern IDE environment. The movement blends refined minimalism with subtle technical glassmorphism and ambient luminescent glows.

## Colors

The palette operates across a calibrated dark spectrum:

- **Primary (`#00F2FE` - Electric Cyan):** Reserved for primary interactive anchors, callouts, active state indicators, and glowing telemetry lines.
- **Secondary (`#10E89A` - Vivid Emerald):** Signals stability, production-ready metrics, positive impact indicators, uptime, and featured achievements.
- **Tertiary (`#38BDF8` - Sky Slate):** Provides soft informational highlights, supporting code token colors, and secondary link states.
- **Neutral (`#0F172A` - Deep Obsidian/Slate):** The baseline tone. Background surfaces step from root obsidian (`#070B12`) to canvas slate (`#0B111E`), card container surface (`#0F172A`), and elevated hover/glass states (`#1E293B`).
- **Surface Borders (`rgba(56, 189, 248, 0.12)` to `rgba(255, 255, 255, 0.08)`):** Ghost borders defining component boundaries without visual clutter.

## Typography

Typography establishes an instant dichotomy between human-centered executive narrative and technical execution:

- **Inter** handles narrative clarity, headlines, and core prose with tight tracking on headings (`-0.03em`) for a sculpted architectural feel.
- **JetBrains Mono** surfaces technical taxonomy: tech stacks, repository metadata, git SHA tags, key performance metric labels, and interactive code blocks. All uppercase labels must utilize expanded letter-spacing (`0.06em` to `0.08em`) to guarantee legibility against deep dark canvas backgrounds.

## Layout & Spacing

A 12-column responsive grid governs desktop presentation with a maximum container threshold of 1240px to ensure terminal-like focus without edge-to-edge eye fatigue.

- **Desktop (1024px+):** 12 columns, 1.5rem gutters, 3rem canvas edge margins. Key architectural case studies utilize asymmetric 7/5 or 8/4 column splits (narrative context vs. architecture schema/metric cards).
- **Tablet (768px - 1023px):** 8 columns, 1.25rem gutters, 2rem margins. Supporting sidebars wrap underneath primary problem-statement cards.
- **Mobile (< 768px):** 4 columns, 1rem gutters, 1.25rem margins. All complex metrics and architecture matrices reflow cleanly into vertical card stacks.

## Elevation & Depth

Depth is produced through subtle tonal layering, frosted dark glass surfaces, and localized luminescent edge glows:

- **Base Layer (Level 0):** Pure dark background (`#070B12`) with optional subtle micro-dot grid pattern (`rgba(255, 255, 255, 0.03)`).
- **Card Surfaces (Level 1):** Solid slate base (`#0F172A`) or translucent glass (`rgba(15, 23, 42, 0.75)` with `backdrop-filter: blur(12px)`). Defined by a hairline border: `1px solid rgba(255, 255, 255, 0.08)`.
- **Raised & Active Elements (Level 2):** Elevated interactive cards on hover shift their hairline borders to `rgba(0, 242, 254, 0.35)` with an ambient drop-shadow: `0 12px 32px -8px rgba(0, 242, 254, 0.12), 0 4px 12px -2px rgba(0, 0, 0, 0.4)`.
- **Overlays & Drawers (Level 3):** Modal inspections, code drawer sheets, and navigation bars use deep slate glass (`rgba(11, 17, 30, 0.85)` with `backdrop-filter: blur(16px)` and shadow `0 24px 48px -12px rgba(0, 0, 0, 0.7)`).

## Shapes

The design system maintains a balanced roundedness (Token: `2` - 0.5rem base radius). Cards, previews, and larger interaction surfaces leverage `rounded-lg` (1rem) for an intentional software-suite finish. Technical elements—such as code blocks, status pips, terminal windows, and pill badges—employ strict geometric intent:

- **Buttons & Tech Chips:** Rounded pills (`9999px`) or `0.5rem` rectangles with razor-sharp vector icons.
- **Project & Metric Cards:** `1rem` outer radius with matching nested inner radii (`0.5rem`) to maintain proportional concentricity.
- **Interactive Focus Rings:** Crisp 2px offset cyan rings (`offset 2px`, color `#00F2FE`).

## Components

### Buttons
- **Primary:** Solid electric cyan fill (`#00F2FE`), deep obsidian text (`#070B12`, font weight 600), pill-shaped (`9999px`) or `rounded-md`, glowing cyan hover halo (`0 0 20px rgba(0, 242, 254, 0.4)`).
- **Secondary/Ghost:** Translucent slate (`rgba(255, 255, 255, 0.05)`), border `1px solid rgba(255, 255, 255, 0.15)`, text `#F8FAFC`. On hover, border shifts to cyan (`rgba(0, 242, 254, 0.5)`) with subtle cyan text illumination.
- **Code Action Button:** Monospaced (`JetBrains Mono`), padding `space-xs` `space-sm`, ghost outline with integrated copy icon.

### Tech Stack Badges & Chips
- Compact pills styled with monospaced typography (`label-md` or `label-sm`).
- Deep slate tint (`rgba(15, 23, 42, 0.8)`), bordered with low-opacity cyan or emerald (`rgba(0, 242, 254, 0.2)` or `rgba(16, 232, 154, 0.2)`).
- Prefix with technology-specific SVG micro-icons or glowing categorical pips (e.g., green for backend, cyan for cloud/infra, sky for frontend).

### Project & Architecture Cards
- Outer container: `rounded-lg`, background `#0F172A`, 1px border `rgba(255, 255, 255, 0.07)`.
- Internal sections: Header with title, company/year badge, and live preview link; body with high-impact architectural problem statement; footer with metrics grid (e.g., "Latency: -42%", "Throughput: 120k rps") highlighted in vivid emerald (`#10E89A`).

### Terminal / Code Preview Blocks
- Slate-black surface (`#070B12`) styled with classic macOS/Linux window controls (subtle muted red, yellow, green micro-dots).
- Syntax highlighting keyed off the system palette: cyan (`#00F2FE`) for keywords/methods, emerald (`#10E89A`) for strings, slate-400 for structural punctuation.

### Metric Callout Tiles
- Focused statistic containers highlighting business and technical impact.
- Monospaced metric figures (e.g., "99.99%", "3.2x") sized at `display-xl` in gradient electric cyan to emerald, accompanied by a compact `label-sm` descriptive label beneath.

### Input Fields & Contact Triggers
- Sleek inputs with background `rgba(15, 23, 42, 0.6)`, hairline border `rgba(255, 255, 255, 0.12)`, text `#F8FAFC`.
- Focus state activates an electric cyan glow line and border color `#00F2FE` with 0% opacity latency.